# AgencyX — School Project

This is an educational, original website template designed to teach HTML/CSS/JS and demonstrate an authoritative layout.
It is fictional and must not be used to impersonate any real government agency.

Files in this package:
- index.html — main single-file landing page (responsive, dark mode toggle, demo contact form)
- README_AgencyX.md — this file

How to publish with GitHub Pages (mobile web UI):
1. Sign in to GitHub on your phone.
2. Create a new repository (e.g., `agencyx-project`).
3. In the repo, choose **Add file → Upload files**.
4. Upload `index.html` from your phone's Downloads (or file manager).
5. Commit changes with message: "Initial upload of site".
6. Go to **Settings → Pages** and select Source: **main / (root)** and save.
7. Visit the provided URL: `https://yourusername.github.io/agencyx-project/`

Keep the footer disclaimer visible: "Educational mockup — not an official government site."
