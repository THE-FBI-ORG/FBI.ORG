const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const sqlite3 = require('sqlite3').verbose();
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// Storage
const uploadDir = path.join(__dirname, 'uploads');
if(!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

// Multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/[^a-zA-Z0-9.\-]/g,'_'))
});
const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

// SQLite DB
const dbFile = path.join(__dirname, 'data.db');
const db = new sqlite3.Database(dbFile);
db.serialize(()=>{
  db.run(`CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    contact TEXT,
    anonymous INTEGER DEFAULT 1,
    file TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
});

// Twilio (optional)
const TWILIO_SID = process.env.TWILIO_ACCOUNT_SID || '';
const TWILIO_TOKEN = process.env.TWILIO_AUTH_TOKEN || '';
const TWILIO_FROM = process.env.TWILIO_WHATSAPP_FROM || ''; // e.g. +1415XXXXXXX
const ADMIN_WHATSAPP_TO = process.env.ADMIN_WHATSAPP_TO || ''; // comma separated

let twilioClient = null;
if(TWILIO_SID && TWILIO_TOKEN){
  const twilio = require('twilio');
  twilioClient = twilio(TWILIO_SID, TWILIO_TOKEN);
  console.log('Twilio configured');
} else {
  console.log('Twilio NOT configured - will fallback to Click-to-Chat links');
}

// POST /api/report
app.post('/api/report', upload.single('file'), (req, res) => {
  const { title, description, contact } = req.body;
  const anonymous = req.body.anonymous === 'on' || req.body.anonymous === 'true' || req.body.anonymous === 1;
  if(!title || !description) return res.status(400).json({ error: 'Missing title or description' });
  const file = req.file ? req.file.filename : null;

  db.run(`INSERT INTO reports (title, description, contact, anonymous, file) VALUES (?, ?, ?, ?, ?)`, [title, description, contact || null, anonymous ? 1 : 0, file], function(err){
    if(err) { console.error(err); return res.status(500).json({ error: 'DB error' }); }
    const id = this.lastID;

    // Notify admins via Twilio if configured
    const messageBody = `New report (#${id}): ${title}\n${description.slice(0,200)}${description.length>200 ? '...' : ''}`;
    if(twilioClient && TWILIO_FROM && ADMIN_WHATSAPP_TO){
      const tos = ADMIN_WHATSAPP_TO.split(',').map(s=>s.trim()).filter(Boolean);
      tos.forEach(to => {
        twilioClient.messages.create({
          from: 'whatsapp:' + TWILIO_FROM,
          to: 'whatsapp:' + to,
          body: messageBody
        }).then(m=>console.log('Sent WhatsApp msg', m.sid)).catch(e=>console.error('Twilio error', e));
      });
      return res.json({ ok:true, id });
    } else {
      // Generate wa.me links for admins (store nothing extra)
      const tos = ADMIN_WHATSAPP_TO.split(',').map(s=>s.trim()).filter(Boolean);
      const wa_links = tos.map(to => `https://wa.me/${to.replace(/[^0-9]/g,'')}?text=${encodeURIComponent(messageBody)}`);
      return res.json({ ok:true, id, wa_links });
    }
  });
});

// Simple admin login
app.post('/api/auth/login', (req, res) => {
  const pass = req.body.password || '';
  if(!process.env.ADMIN_PASSWORD) return res.status(500).json({ error: 'ADMIN_PASSWORD not set on server' });
  if(pass !== process.env.ADMIN_PASSWORD) return res.status(401).json({ error: 'Invalid' });
  const token = jwt.sign({ admin: true }, process.env.JWT_SECRET || 'dev_secret', { expiresIn: '8h' });
  res.json({ token });
});

// Protected: list reports
function checkAuth(req, res, next){
  const h = req.headers.authorization || '';
  const m = h.match(/^Bearer\s+(.+)$/i);
  if(!m) return res.status(401).json({ error: 'No token' });
  try{
    const payload = jwt.verify(m[1], process.env.JWT_SECRET || 'dev_secret');
    if(payload && payload.admin) return next();
    return res.status(401).json({ error: 'Invalid' });
  } catch(e){ return res.status(401).json({ error: 'Invalid' }); }
}

app.get('/api/admin/reports', checkAuth, (req, res) => {
  db.all('SELECT id, title, description, contact, anonymous, file, created_at FROM reports ORDER BY id DESC LIMIT 200', [], (err, rows) => {
    if(err) return res.status(500).json({ error: 'DB error' });
    // If Twilio not configured, include wa_link for each report using ADMIN_WHATSAPP_TO
    const tos = (process.env.ADMIN_WHATSAPP_TO||'').split(',').map(s=>s.trim()).filter(Boolean);
    const includeWa = !twilioClient && tos.length>0;
    const rowsOut = rows.map(r=>{
      const out = Object.assign({}, r);
      if(includeWa){
        const body = `Report #${r.id}: ${r.title} - ${r.description.slice(0,200)}`;
        out.wa_link = `https://wa.me/${tos[0].replace(/[^0-9]/g,'')}?text=${encodeURIComponent(body)}`;
      }
      return out;
    });
    res.json(rowsOut);
  });
});

// Download file
app.get('/api/admin/report/:id/file', checkAuth, (req, res) => {
  const id = req.params.id;
  db.get('SELECT file FROM reports WHERE id = ?', [id], (err, row) => {
    if(err || !row) return res.status(404).json({ error: 'Not found' });
    if(!row.file) return res.status(404).json({ error: 'No file' });
    const p = path.join(uploadDir, row.file);
    res.sendFile(p);
  });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, ()=> console.log('Server running on port', PORT));
