
# Investigation Website (Phone-friendly deploy)

This repo contains a simple front-end (React) and backend (Node+Express with SQLite) that together create a small community reporting site. It includes an **admin** area to view reports and an optional **WhatsApp** integration.

Key features:
- Submit reports with optional photo/video.
- Admin can view reports (login required).
- Optional automated WhatsApp notifications via Twilio, or click-to-chat links if Twilio is not configured.
- Designed so you can upload this ZIP to GitHub from your phone and deploy frontend & backend without a computer.

---
## Quick mobile-friendly deployment plan (no computer)

1. Upload this ZIP to a new GitHub repo (use the GitHub mobile site -> Add file -> Upload files).
2. Frontend (recommended): Deploy to **Vercel** (mobile-friendly)
   - Go to https://vercel.com, Sign in with GitHub, Import Project, choose this GitHub repo, set Root Directory to `frontend`.
   - In Vercel settings: set environment variable `REACT_APP_API_BASE` to your backend URL (you'll get it after deploying backend).
   - Deploy — Vercel will build and give you a public URL for the frontend.
3. Backend: Deploy to **Render** (or Railway)
   - Go to https://render.com, Sign in with GitHub, click New -> Web Service -> Connect Repo.
   - Choose the repo and set the Root Directory to `backend`.
   - Build Command: `npm install`
   - Start Command: `npm start`
   - In Environment: add env vars from `backend/.env.example` (at minimum set ADMIN_PASSWORD and JWT_SECRET; optional Twilio vars for WhatsApp)
   - Deploy — Render gives you a public `https://...onrender.com` URL.
4. After backend is deployed, copy its URL and add it to Vercel env `REACT_APP_API_BASE` and redeploy frontend.
5. Open the frontend URL on your phone and test submitting a report. Then go to /admin, login with the ADMIN_PASSWORD you set, and view reports.

---
## WhatsApp options

- **Fast & free (manual send):** Do not configure Twilio. Admin dashboard will show a button that opens WhatsApp with a pre-filled message (Click-to-Chat). Admin taps to send from their phone.
- **Automated (server sends):** Create a Twilio account with WhatsApp enabled (or use Meta Business Cloud API). Fill `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, and `TWILIO_WHATSAPP_FROM` in backend environment variables and set `ADMIN_WHATSAPP_TO`. The server will send messages automatically when a new report arrives.

---
## Notes & legal
- This is a demo/starting point. Do not impersonate law enforcement. Add clear disclaimers and a privacy policy.
- For production: use HTTPS everywhere, secure file storage (S3), proper admin auth (MFA), virus scanning, and legal review.
