import React, {useState, useEffect} from 'react';

const API_BASE = process.env.REACT_APP_API_BASE || '';

function Home(){ 
  return (
    <div className="container">
      <h1>Civic Witness</h1>
      <p>Community reporting — for emergencies call your local emergency number.</p>
      <a href="/report" className="btn">Submit a Tip</a>
      <a href="/admin" className="btn">Admin</a>
    </div>
  )
}

function Report(){
  const [status, setStatus] = useState(null);
  async function submit(e){
    e.preventDefault();
    setStatus('Submitting...');
    const form = e.target;
    const fd = new FormData(form);
    try{
      const res = await fetch((API_BASE || '') + '/api/report', {
        method: 'POST',
        body: fd
      });
      const j = await res.json();
      if(res.ok){
        setStatus('Report submitted. Thank you.');
        form.reset();
      } else {
        setStatus(j.error || 'Error submitting');
      }
    } catch(err){
      console.error(err);
      setStatus('Network error');
    }
  }
  return (
    <div className="container">
      <h2>Report a Tip</h2>
      <form onSubmit={submit} encType="multipart/form-data">
        <input name="title" placeholder="Title" required />
        <textarea name="description" placeholder="Description" required />
        <input name="contact" placeholder="Your contact (optional)" />
        <label><input type="checkbox" name="anonymous" defaultChecked /> Submit anonymously</label>
        <input type="file" name="file" />
        <button className="btn" type="submit">Send</button>
      </form>
      {status && <p className="status">{status}</p>}
    </div>
  )
}

function Admin(){
  const [token, setToken] = useState(localStorage.getItem('admin_token') || '');
  const [password, setPassword] = useState('');
  const [reports, setReports] = useState([]);

  async function login(e){
    e.preventDefault();
    if(!password) return alert('Enter password');
    const res = await fetch((API_BASE || '') + '/api/auth/login', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({password})
    });
    const j = await res.json();
    if(res.ok){
      localStorage.setItem('admin_token', j.token);
      setToken(j.token);
      setPassword('');
    } else {
      alert(j.error || 'Login failed');
    }
  }

  async function loadReports(){
    const res = await fetch((API_BASE || '') + '/api/admin/reports', {
      headers: { Authorization: 'Bearer ' + token }
    });
    if(res.ok){
      setReports(await res.json());
    } else {
      if(res.status===401) { localStorage.removeItem('admin_token'); setToken(''); }
      const j = await res.json().catch(()=>({})); alert(j.error || 'Failed to load reports');
    }
  }

  useEffect(()=>{ if(token) loadReports(); }, [token]);

  async function openWhatsapp(report){
    // Backend may provide wa_link in report if Twilio not configured.
    if(report.wa_link){
      window.open(report.wa_link, '_blank');
      return;
    }
    alert('No WhatsApp link available.');
  }

  return (
    <div className="container">
      <h2>Admin</h2>
      {!token && (
        <form onSubmit={login}>
          <input type="password" placeholder="Admin password" value={password} onChange={e=>setPassword(e.target.value)} />
          <button className="btn" type="submit">Login</button>
        </form>
      )}
      {token && (
        <>
          <button className="btn" onClick={loadReports}>Load reports</button>
          <button className="btn" onClick={()=>{ localStorage.removeItem('admin_token'); setToken(''); setReports([]); }}>Logout</button>
          <div>
            {reports.length===0 && <p>No reports</p>}
            {reports.map(r=>(
              <div key={r.id} className="card">
                <h4>{r.title}{r.anonymous ? ' (anonymous)' : ''}</h4>
                <p>{r.description}</p>
                <p><small>Received: {r.created_at}</small></p>
                {r.file && <a href={(API_BASE || '') + '/api/admin/report/' + r.id + '/file'} target="_blank" rel="noreferrer">Download attachment</a>}
                <div style={{marginTop:8}}>
                  <button className="btn" onClick={()=>openWhatsapp(r)}>Open WhatsApp</button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}

export default function App(){
  const [path, setPath] = useState(window.location.pathname);
  useEffect(()=>{ const onpop=()=>setPath(window.location.pathname); window.addEventListener('popstate', onpop); return ()=>window.removeEventListener('popstate', onpop); },[]);
  const navigate = (to)=>{ window.history.pushState({},'',to); setPath(to); };
  useEffect(()=>{ document.querySelectorAll('a[href^="/"]').forEach(a=>{ a.onclick = (e)=>{ e.preventDefault(); navigate(a.getAttribute('href')); }; }); }, []);
  if(path === '/report') return <Report />;
  if(path === '/admin') return <Admin />;
  return <Home />;
}
